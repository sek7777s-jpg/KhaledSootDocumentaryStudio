package com.khaledsoot.documentary;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import androidx.media3.common.MediaItem;
import androidx.media3.common.Effect;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.Effects;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.Transformer;
import androidx.media3.effect.OverlayEffect;
import androidx.media3.effect.TextureOverlay;
import androidx.media3.effect.BitmapOverlay;
import androidx.media3.effect.StaticOverlaySettings;
import androidx.media3.effect.Presentation;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import android.media.MediaMetadataRetriever;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextDirectionHeuristics;
import android.os.Handler;
import android.os.Looper;

@UnstableApi
public class MainActivity extends Activity {
    private static final int PICK_VIDEO = 101;
    private static final int PICK_LOGO = 102;
    private Uri videoUri, logoUri;
    private TextView videoStatus, progressText;
    private EditText introTitle, introSub, tickerOne, tickerTwo, outroText;
    private Button exportButton, logoButton;
    private ProgressBar progressBar;
    private boolean exporting = false;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildScreen();
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(13, 20, 32));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(28));
        scroll.addView(root);

        TextView brand = new TextView(this);
        brand.setText("KHALED SOOT\nاستوديو خالد صوت الوثائقي");
        brand.setTextColor(Color.WHITE);
        brand.setTextSize(24);
        brand.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        brand.setGravity(Gravity.CENTER);
        brand.setPadding(0, dp(12), 0, dp(16));
        root.addView(brand);

        TextView subtitle = new TextView(this);
        subtitle.setText("إنتاج التقارير والأفلام الوثائقية من هاتفك");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(14);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, 0, 0, dp(18));
        root.addView(subtitle);

        Button choose = makeButton("🎬  اختيار فيديو من الهاتف");
        root.addView(choose);
        choose.setOnClickListener(v -> pickVideo());
        videoStatus = new TextView(this);
        videoStatus.setText("لم يتم اختيار فيديو بعد");
        videoStatus.setTextColor(Color.LTGRAY);
        videoStatus.setPadding(dp(4), dp(8), dp(4), dp(14));
        root.addView(videoStatus);

        addSection(root, "١. مقدمة الفيلم");
        introTitle = addField(root, "عنوان الفيلم أو التقرير", "تقرير خاص | تطورات ميدانية");
        introSub = addField(root, "سطر تعريفي (اختياري)", "إعداد وتصوير: خالد صوت");

        addSection(root, "٢. الشريطان الإخباريان المتحركان");
        tickerOne = addField(root, "الشريط الأول – العنوان الرئيسي", "تابعونا | Khaled Soot");
        tickerTwo = addField(root, "الشريط الثاني – التفاصيل أو المصدر", "تغطية خاصة من موقع الحدث");

        addSection(root, "٣. شعار القناة");
        logoButton = makeButton("🖼  اختيار شعار من المعرض (اختياري)");
        root.addView(logoButton);
        logoButton.setOnClickListener(v -> pickLogo());
        TextView logoNote = smallNote("إذا لم تختر شعارًا، سيظهر شعار نصي باسم KHALED SOOT في الركن العلوي.");
        root.addView(logoNote);

        addSection(root, "٤. خاتمة الفيلم");
        outroText = addField(root, "نص الخاتمة", "شكرًا لمتابعتكم\nإعداد وتقديم: خالد صوت\nتابعونا khaled soot");

        addSection(root, "٥. إعدادات التصدير");
        TextView quality = smallNote("الجودة: 720p (ضلع قصير 720)  •  الصيغة: MP4  •  الصوت الأصلي محفوظ");
        root.addView(quality);
        TextView tickerInfo = smallNote("الشريطان يتحركان تلقائيًا طوال الفيديو. تظهر المقدمة في أول 4 ثوانٍ والخاتمة في آخر 4 ثوانٍ.");
        root.addView(tickerInfo);

        exportButton = makeButton("🚀  إنشاء الفيديو الوثائقي");
        exportButton.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(190, 35, 48)));
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-1, dp(54));
        ep.topMargin = dp(18);
        root.addView(exportButton, ep);
        exportButton.setOnClickListener(v -> startExport());

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setVisibility(View.GONE);
        root.addView(progressBar, new LinearLayout.LayoutParams(-1, dp(8)));
        progressText = new TextView(this);
        progressText.setTextColor(Color.WHITE);
        progressText.setGravity(Gravity.CENTER);
        root.addView(progressText);

        TextView foot = new TextView(this);
        foot.setText("Khaled Soot © 2026");
        foot.setTextColor(Color.GRAY);
        foot.setGravity(Gravity.CENTER);
        foot.setPadding(0, dp(24), 0, 0);
        root.addView(foot);

        setContentView(scroll);
    }

    private void addSection(LinearLayout root, String title) {
        TextView t = new TextView(this);
        t.setText(title);
        t.setTextColor(Color.rgb(255, 205, 95));
        t.setTextSize(17);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(0, dp(18), 0, dp(8));
        root.addView(t);
    }

    private EditText addField(LinearLayout root, String hint, String value) {
        EditText e = new EditText(this);
        e.setSingleLine(false);
        e.setMinLines(1);
        e.setText(value);
        e.setHint(hint);
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(Color.GRAY);
        e.setTextSize(15);
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(100, 120, 145)));
        e.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        e.setTextDirection(View.TEXT_DIRECTION_RTL);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = dp(8);
        root.addView(e, p);
        return e;
    }

    private TextView smallNote(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Color.LTGRAY);
        t.setTextSize(12);
        t.setPadding(dp(4), dp(5), dp(4), dp(8));
        return t;
    }

    private Button makeButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(14);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(35, 83, 125)));
        return b;
    }

    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }

    private void pickVideo() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("video/*");
        startActivityForResult(i, PICK_VIDEO);
    }

    private void pickLogo() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        startActivityForResult(i, PICK_LOGO);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
        catch (Exception ignored) {}
        if (requestCode == PICK_VIDEO) {
            videoUri = uri;
            videoStatus.setText("تم اختيار الفيديو بنجاح ✓");
        } else if (requestCode == PICK_LOGO) {
            logoUri = uri;
            logoButton.setText("✓ تم اختيار الشعار من المعرض");
        }
    }

    private void startExport() {
        if (videoUri == null) {
            Toast.makeText(this, "اختر فيديو أولاً", Toast.LENGTH_LONG).show();
            return;
        }
        if (exporting) return;
        hideKeyboard();
        exporting = true;
        exportButton.setEnabled(false);
        progressBar.setVisibility(View.VISIBLE);
        progressBar.setProgress(0);
        progressText.setText("جارٍ تجهيز الفيديو...");
        try {
            long durationUs = getDurationUs(videoUri);
            if (durationUs <= 0) throw new IllegalStateException("تعذر قراءة مدة الفيديو");
            Bitmap logo = loadLogo();
            DocumentaryOverlay overlay = new DocumentaryOverlay(
                    introTitle.getText().toString().trim(),
                    introSub.getText().toString().trim(),
                    tickerOne.getText().toString().trim(),
                    tickerTwo.getText().toString().trim(),
                    outroText.getText().toString().trim(),
                    durationUs, logo);

            List<TextureOverlay> overlays = Collections.singletonList(overlay);
            Effect overlayEffect = new OverlayEffect(overlays);
            List<Effect> videoEffects = Arrays.asList(
                    overlayEffect,
                    Presentation.createForShortSide(720)
            );
            Effects effects = new Effects(Collections.emptyList(), videoEffects);
            MediaItem mediaItem = new MediaItem.Builder().setUri(videoUri).build();
            EditedMediaItem edited = new EditedMediaItem.Builder(mediaItem)
                    .setEffects(effects)
                    .build();

            File outDir = new File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), "KhaledSoot");
            if (!outDir.exists() && !outDir.mkdirs()) throw new IllegalStateException("تعذر إنشاء مجلد الحفظ");
            File output = new File(outDir, "KhaledSoot_Documentary_" + System.currentTimeMillis() + ".mp4");

            Transformer transformer = new Transformer.Builder(this)
                    .setVideoMimeType(androidx.media3.common.MimeTypes.VIDEO_H264)
                    .addListener(new Transformer.Listener() {
                        @Override public void onCompleted(Composition composition, ExportResult exportResult) {
                            runOnUiThread(() -> onExportDone(output));
                        }
                        @Override public void onError(Composition composition, ExportResult exportResult, ExportException exportException) {
                            runOnUiThread(() -> onExportError(exportException));
                        }
                    })
                    .build();
            transformer.start(edited, output.getAbsolutePath());
            progressText.setText("بدأ التصدير. قد يستغرق وقتًا حسب طول الفيديو والهاتف...");
            watchProgress(transformer);
        } catch (Exception e) {
            onExportError(e);
        }
    }

    private void watchProgress(Transformer transformer) {
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                if (!exporting) return;
                androidx.media3.transformer.ProgressHolder holder = new androidx.media3.transformer.ProgressHolder();
                int state = transformer.getProgress(holder);
                if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                    progressBar.setProgress(holder.progress);
                    progressText.setText("جارٍ إنشاء الفيديو: " + holder.progress + "%");
                }
                handler.postDelayed(this, 700);
            }
        }, 700);
    }

    private long getDurationUs(Uri uri) throws Exception {
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        retriever.setDataSource(this, uri);
        String d = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
        retriever.release();
        return (d == null ? 0 : Long.parseLong(d)) * 1000L;
    }

    private Bitmap loadLogo() {
        if (logoUri == null) return null;
        try (InputStream in = getContentResolver().openInputStream(logoUri)) {
            Bitmap b = BitmapFactory.decodeStream(in);
            if (b == null) return null;
            return Bitmap.createScaledBitmap(b, 150, 90, true);
        } catch (Exception e) { return null; }
    }

    private void onExportDone(File file) {
        exporting = false;
        exportButton.setEnabled(true);
        progressBar.setProgress(100);
        progressText.setText("اكتمل إنشاء الفيديو ✓\nجارٍ حفظه في معرض الهاتف...");
        try {
            Uri saved = copyToGallery(file);
            progressText.setText("تم حفظ الفيديو بنجاح في Movies / KhaledSoot ✓");
            Toast.makeText(this, "تم إنشاء الفيلم الوثائقي وحفظه في المعرض", Toast.LENGTH_LONG).show();
            if (saved != null) {
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("video/mp4");
                share.putExtra(Intent.EXTRA_STREAM, saved);
                share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(share, "مشاركة الفيلم الوثائقي"));
            }
        } catch (Exception e) {
            progressText.setText("اكتمل التصدير، لكن تعذر نسخه إلى المعرض: " + e.getMessage()
                    + "\nالملف محفوظ داخل مجلد التطبيق.");
        }
    }

    private Uri copyToGallery(File file) throws Exception {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Video.Media.DISPLAY_NAME, file.getName());
        values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
        if (Build.VERSION.SDK_INT >= 29) {
            values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/KhaledSoot");
            values.put(MediaStore.Video.Media.IS_PENDING, 1);
        }
        Uri uri = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new IllegalStateException("تعذر إنشاء ملف في المعرض");
        try (InputStream in = new FileInputStream(file);
             OutputStream out = getContentResolver().openOutputStream(uri)) {
            byte[] buffer = new byte[1024 * 1024];
            int n;
            while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
        }
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues done = new ContentValues();
            done.put(MediaStore.Video.Media.IS_PENDING, 0);
            getContentResolver().update(uri, done, null, null);
        }
        return uri;
    }

    private void onExportError(Exception e) {
        exporting = false;
        exportButton.setEnabled(true);
        progressText.setText("تعذر إنشاء الفيديو:\n" + e.getMessage());
        Toast.makeText(this, "حدث خطأ أثناء التصدير", Toast.LENGTH_LONG).show();
    }

    private void hideKeyboard() {
        try {
            InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(exportButton.getWindowToken(), 0);
        } catch (Exception ignored) {}
    }

    private static class DocumentaryOverlay extends BitmapOverlay {
        private final Bitmap frame = Bitmap.createBitmap(1280, 720, Bitmap.Config.ARGB_8888);
        private final Canvas canvas = new Canvas(frame);
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final String title, subtitle, firstTicker, secondTicker, outro;
        private final long durationUs;
        private final Bitmap logo;
        private final StaticOverlaySettings settings = new StaticOverlaySettings.Builder()
                .setOverlayFrameAnchor(0f, 0f)
                .setBackgroundFrameAnchor(0f, 0f)
                .build();

        DocumentaryOverlay(String title, String subtitle, String firstTicker,
                           String secondTicker, String outro, long durationUs, Bitmap logo) {
            this.title = title.isEmpty() ? "تقرير وثائقي" : title;
            this.subtitle = subtitle;
            this.firstTicker = firstTicker;
            this.secondTicker = secondTicker;
            this.outro = outro;
            this.durationUs = durationUs;
            this.logo = logo;
        }

        @Override public Bitmap getBitmap(long timeUs) {
            canvas.drawColor(Color.TRANSPARENT, android.graphics.PorterDuff.Mode.CLEAR);
            drawLogo();
            drawTicker(0, firstTicker, Color.rgb(190, 28, 42), timeUs, 190f);
            drawTicker(54, secondTicker, Color.rgb(20, 37, 58), timeUs + 900000L, 145f);

            if (timeUs < 4_000_000L) drawTitleCard(timeUs);
            if (timeUs > durationUs - 4_000_000L) drawOutro(timeUs);
            return frame;
        }

        @Override public androidx.media3.common.util.Size getTextureSize(long presentationTimeUs) {
            return new androidx.media3.common.util.Size(1280, 720);
        }

        @Override public androidx.media3.common.OverlaySettings getOverlaySettings(long presentationTimeUs) {
            return settings;
        }

        private void drawLogo() {
            paint.setColor(Color.argb(205, 10, 18, 30));
            canvas.drawRoundRect(new RectF(1010, 24, 1250, 100), 14, 14, paint);
            if (logo != null) {
                canvas.drawBitmap(logo, 1080, 27, paint);
            } else {
                paint.setColor(Color.WHITE);
                paint.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
                paint.setTextSize(31);
                paint.setTextAlign(Paint.Align.CENTER);
                canvas.drawText("KHALED SOOT", 1130, 72, paint);
            }
        }

        private void drawTicker(float y, String text, int color, long t, float speed) {
            if (text == null || text.trim().isEmpty()) return;
            paint.setColor(color);
            canvas.drawRect(0, 610 + y, 1280, 662 + y, paint);
            paint.setColor(Color.WHITE);
            paint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
            paint.setTextSize(26);
            String line = "   " + text + "     ◆     " + text + "     ◆     ";
            float width = paint.measureText(line);
            float x = 1280 - ((t / 1000f / 1000f * speed) % (width + 1280));
            canvas.save();
            canvas.clipRect(0, 610 + y, 1280, 662 + y);
            canvas.drawText(line, x, 646 + y, paint);
            canvas.drawText(line, x + width, 646 + y, paint);
            canvas.restore();
        }

        private void drawTitleCard(long t) {
            float alpha = t < 500000 ? (t / 500000f) : (t > 3500000 ? (4000000f - t) / 500000f : 1f);
            alpha = Math.max(0f, Math.min(1f, alpha));
            paint.setColor(Color.argb((int)(alpha * 175), 3, 12, 24));
            canvas.drawRect(0, 0, 1280, 720, paint);
            paint.setColor(Color.rgb(205, 35, 48));
            canvas.drawRect(110, 270, 1170, 278, paint);
            drawCentered(title, 350, 58, Color.WHITE, alpha);
            if (!subtitle.isEmpty()) drawCentered(subtitle, 420, 30, Color.rgb(235, 205, 145), alpha);
            paint.setColor(Color.WHITE);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTextSize(18);
            canvas.drawText("KHALED SOOT  |  DOCUMENTARY", 640, 500, paint);
        }

        private void drawOutro(long t) {
            paint.setColor(Color.argb(190, 4, 12, 24));
            canvas.drawRect(0, 0, 1280, 720, paint);
            String[] lines = outro.split("\\n");
            int y = 300;
            for (String line : lines) {
                drawCentered(line, y, 38, Color.WHITE, 1f);
                y += 58;
            }
        }

        private void drawCentered(String text, int baseline, float size, int color, float alpha) {
            paint.setColor(color);
            paint.setAlpha((int)(255 * alpha));
            paint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
            paint.setTextSize(size);
            paint.setTextAlign(Paint.Align.CENTER);
            canvas.drawText(text, 640, baseline, paint);
        }
    }
}
